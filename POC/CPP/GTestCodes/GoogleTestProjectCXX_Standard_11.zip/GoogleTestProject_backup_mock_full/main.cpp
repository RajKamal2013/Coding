#include <iostream>

#include "IDatabaseConnection.hpp"
#include "Employee.hpp"
#include "EmployeeManager.hpp"

int main(int argc, char **argv)
{
  std::cout << "Do something with your library code\n";
  return 0;
}
