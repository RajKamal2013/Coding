rootProject.name = "movie-recommender-system"
