package io.datajek.springbootdemo.recommenderapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecommenderApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
