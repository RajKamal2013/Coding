package io.datajek.springbasics.movierecommendersystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRecommenderSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
